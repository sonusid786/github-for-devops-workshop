# Eqbal Ansari — AWS Portfolio Deployment

A responsive static portfolio built with HTML, CSS and JavaScript. GitHub Actions deploys it to an AWS S3 bucket using GitHub OIDC (recommended; no permanent AWS access keys in GitHub).

## 1. Customize the portfolio
- Update `YOUR_EMAIL@example.com` in `index.html`.
- Replace LinkedIn and GitHub links with your real profile URLs.
- Add real repository links and only list projects/skills you can explain in an interview.
- Preview locally by opening `index.html` in a browser.

## 2. Create an S3 bucket
Create a globally unique S3 bucket in your chosen AWS region. Keep Block Public Access enabled if you plan to serve the site through CloudFront with Origin Access Control. For a learning-only public S3 website endpoint, public access configuration is required and is less secure.

## 3. Configure GitHub OIDC in AWS
In AWS IAM, create an identity provider:
- Provider URL: `https://token.actions.githubusercontent.com`
- Audience: `sts.amazonaws.com`

Create an IAM role trusted by that provider. Restrict the trust policy to your repository and branch. Replace `YOUR_GITHUB_ORG/YOUR_REPO` with the exact GitHub owner/repository:

```json
{
  "Version": "2012-10-17",
  "Statement": [{
    "Effect": "Allow",
    "Principal": {
      "Federated": "arn:aws:iam::YOUR_AWS_ACCOUNT_ID:oidc-provider/token.actions.githubusercontent.com"
    },
    "Action": "sts:AssumeRoleWithWebIdentity",
    "Condition": {
      "StringEquals": {
        "token.actions.githubusercontent.com:aud": "sts.amazonaws.com",
        "token.actions.githubusercontent.com:sub": "repo:YOUR_GITHUB_ORG/YOUR_REPO:ref:refs/heads/main"
      }
    }
  }]
}
```

Attach a least-privilege permissions policy to the role. Replace the bucket name:

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": ["s3:ListBucket"],
      "Resource": "arn:aws:s3:::YOUR_BUCKET_NAME"
    },
    {
      "Effect": "Allow",
      "Action": ["s3:PutObject", "s3:DeleteObject"],
      "Resource": "arn:aws:s3:::YOUR_BUCKET_NAME/*"
    }
  ]
}
```

If you use CloudFront invalidation, also grant `cloudfront:CreateInvalidation` for the specific distribution ARN.

## 4. Add GitHub repository variables
Open GitHub repository → Settings → Secrets and variables → Actions → Variables, then add:

| Variable | Value |
|---|---|
| `AWS_ROLE_ARN` | IAM role ARN |
| `AWS_REGION` | Your bucket's AWS region, e.g. `ap-south-1` |
| `S3_BUCKET_NAME` | Exact S3 bucket name |
| `CLOUDFRONT_DISTRIBUTION_ID` | Optional; only if using CloudFront |

Do not add AWS access keys. This workflow uses OIDC role assumption.

## 5. Push and deploy

```bash
git init
git add .
git commit -m "Initial portfolio website"
git branch -M main
git remote add origin https://github.com/YOUR_GITHUB_USERNAME/YOUR_REPOSITORY.git
git push -u origin main
```

Then open GitHub → Actions. The workflow should run on every push to `main`.

## Architecture
Developer → GitHub repository → GitHub Actions → OIDC → AWS IAM role → S3 bucket → (optional CloudFront) → Visitor.

## Important
This workflow uploads files to S3; it does not configure website hosting, CloudFront, DNS, HTTPS or bucket policies. Set up the hosting layer separately. For production, prefer a private S3 bucket behind CloudFront Origin Access Control. S3 and CloudFront may incur AWS charges.
